# DeepGuard AI - Deepfake Detection System Using Deep Learning

Group 9 | B.Tech AIML (Second Year) | Python / PyTorch backend (command-line only, no UI)

> **Honest status:** this repository contains the complete code. **No trained weights and no accuracy
> numbers are included**, because the model must be trained on a dataset you download (see
> [Dataset](#4-dataset)). All results will come from *your* training run and are written to `reports/`.

---

## 1. Project overview
DeepGuard AI takes an image or a video, finds the faces, and decides whether each face looks **REAL** or
**FAKE** (manipulated, e.g. face-swap), with a confidence score. It also trains and evaluates the model
and writes reports.

## 2. Problem statement
Deepfakes are realistic fake faces made with AI. They are used for misinformation, fraud and harassment, and
people cannot reliably spot them by eye. We need an automatic, data-driven detector.

## 3. Objectives
1. Detect and extract faces from images and video frames.
2. Train a CNN (EfficientNet-B0, transfer learning) to classify faces REAL / FAKE.
3. Analyse images (multi-face) and videos (frame sampling, suspicious timestamps).
4. Evaluate with accuracy, precision, recall, F1, ROC-AUC, confusion matrix, learning curves.
5. Avoid data leakage between train / validation / test.

**Existing systems:** manual/forensic inspection, metadata checks, and hand-crafted features (blink rate, head pose,
colour inconsistencies) - slow, easy to fool, and weak on new fake methods.
**Proposed system:** an end-to-end learned detector: face detector -> preprocessing -> fine-tuned EfficientNet-B0 -> aggregation.

## 4. Dataset
You must download a public dataset yourself (the code cannot include it). Options, heaviest to lightest:

| Dataset | Type | How to get it | Prepare command |
|---|---|---|---|
| **FaceForensics++** | videos (real + several fake methods) | Request access via the form on the official GitHub (`ondyari/FaceForensics`); you receive a download script. Use the compressed `c23` version and 1-2 manipulation methods (e.g. Deepfakes) to stay small. | `videos` |
| **Celeb-DF v2** | videos | Request form on the official GitHub (`yuezunli/celeb-deepfakeforensics`). Folders: `Celeb-real`, `YouTube-real`, `Celeb-synthesis`. | `videos` |
| **DFDC sample** | videos + `metadata.json` | Kaggle "Deepfake Detection Challenge" (sample/train part). | `dfdc` |
| **Lightweight option:** image dataset such as "140k Real and Fake Faces" on Kaggle (real faces vs StyleGAN-generated faces) | cropped face images | Download from Kaggle, unzip. | `images --no-detect` |

*The image option is the easiest/fastest for a student laptop, but those fakes are **fully GAN-generated faces**, not
face-swaps; mention this in your report.*

### Organise and prepare (run from the project root)
```bash
# A) FaceForensics++ / Celeb-DF style (limit videos so it stays light)
python main.py prepare videos --real-dir PATH/to/real_videos --fake-dir PATH/to/fake_videos --max-videos 150
python main.py prepare split --group-mode identity

# B) DFDC folder (contains metadata.json)
python main.py prepare dfdc --video-dir PATH/to/dfdc_folder --max-videos 150
python main.py prepare split --group-mode video

# C) Lightweight image dataset
python main.py prepare images --real-dir PATH/real --fake-dir PATH/fake --max-images 4000 --no-detect
python main.py prepare split --group-mode video
```
Result: 224x224 face crops in `data/real/` and `data/fake/`, plus `data/splits.csv`
(path, label, group, split = train/val/test; 70/15/15).

**Avoiding data leakage:** frames of one video are almost identical, so whole *groups* go to a single split. Use
`--group-mode identity` for FF++/Celeb-DF (a person's real video and fakes made from them stay together);
DFDC fakes are grouped with their original video automatically. For FF++ you may also use the official
split files: `--group-mode ffpp-official --split-json-dir PATH` (folder with `train.json`, `val.json`, `test.json`).
The split step asserts that no group appears in two splits.

## 5. System architecture
See `docs/architecture_diagram.png` and `docs/flowchart.png` (regenerate with `python docs/generate_diagrams.py`).

```
Training : dataset -> face detection -> 224x224 crops -> group split -> fine-tune EfficientNet-B0 -> weights
Inference: image/video -> validate -> (sample frames) -> face detection -> crop+normalise -> model -> aggregate -> verdict+report
Evaluate : test split -> predictions -> metrics + graphs -> reports/evaluation_report.md
```

## 6. CNN and EfficientNet explained simply
A **CNN** slides small filters over an image to detect edges, then textures, then parts of faces. Deepfakes often
leave tiny artefacts (blending edges, odd textures) that deeper filters can learn.
**EfficientNet-B0** is a small, accurate CNN (about 5 million parameters) that balances depth, width and resolution
(compound scaling) and uses efficient MBConv blocks - good for CPU-limited projects.
**Transfer learning:** we start from weights trained on ImageNet (general vision skills) and only adapt them to
REAL vs FAKE, so we need less data and training time. We replace the last layer (1000 classes) by one neuron;
`sigmoid(output)` = probability the face is FAKE.

## 7. Training procedure (`training/train.py`)
- Loss: `BCEWithLogitsLoss` with `pos_weight` (handles more fakes than reals). Optimiser: `AdamW` (lr 1e-4).
- Epoch 1 trains only the new head (backbone frozen), then the whole network is fine-tuned.
- Augmentation (train only): flip, brightness/contrast, small rotation, JPEG compression.
- Each epoch: train pass, validation pass; the checkpoint with the **lowest validation loss** is saved to
  `weights/deepguard_best.pth`. LR halves on plateau; early stopping after 4 non-improving epochs.
- The **test split is never used in training.**
- Outputs: `reports/training_history.json`, `reports/training_curves.png`.

## 8. Detection methodology
- **Image:** validate -> detect faces (MTCNN, or OpenCV Haar fallback) -> crop with margin -> resize 224 + ImageNet
  normalisation -> model -> per-face P(FAKE). Image verdict: FAKE if **any** face is >= threshold (0.5).
- **Video:** one frame every `--interval` seconds (default 1 s, max 40 frames spread over the video). Frame score = highest face
  score; video score = mean of frame scores; frames >= threshold are listed as **suspicious timestamps**.
- Confidence = P(FAKE) for a FAKE verdict, 1 - P(FAKE) for REAL. No face -> `NO_FACE_DETECTED` / `INCONCLUSIVE`
  (never a guess). If weights are missing the program refuses to predict.

## 9. Evaluation metrics (`training/evaluate.py`)
Accuracy, Precision, Recall, F1 (FAKE is the positive class), Specificity, ROC-AUC, confusion matrix, plus loss/accuracy curves.
Run `python main.py evaluate`; it writes `reports/evaluation_report.md`, `evaluation_metrics.json`, `confusion_matrix.png`,
`roc_curve.png`. Evaluation is **face-level** (per image crop), not video-level.

## 10. Installation
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
pip install facenet-pytorch --no-deps                 # optional: MTCNN detector
python -m unittest discover tests -v                  # sanity tests
```
Works on CPU (slower) and automatically uses a GPU if available. First training run downloads the ImageNet weights (~20 MB, internet needed once).
If the OpenCV build has no Haar cascade, the program tries to download that one small XML into `weights/`.

## 11. Execution
```bash
python main.py                                   # interactive menu (1 image, 2 video, 3 train, 4 evaluate, 5 exit)
python main.py train --epochs 8
python main.py evaluate
python main.py image  photo.jpg --annotate
python main.py video  clip.mp4 --interval 1.0 --max-frames 40
```
Detection reports are saved in `reports/` (`.json` + `.txt`).

```
DeepGuard-AI/
├── main.py  config.py  requirements.txt  README.md
├── models/      deepfake_model.py  model_loader.py
├── detection/   face_detection.py  image_detection.py  video_detection.py
├── training/    preprocess.py  dataset.py  train.py  evaluate.py
├── utils/       metrics.py  visualization.py  report_generator.py
├── data/ real/ fake/ (+ splits.csv after preparation)    weights/    reports/
├── docs/        abstract, report, viva Q&A, faculty explanation, diagrams
└── tests/
```

## 12. Limitations
- Trained on one dataset, the model usually performs **much worse on other datasets or newer fake methods** (poor generalisation).
- Frame-by-frame analysis: no temporal (motion/blink) modelling, no audio.
- Haar fallback misses non-frontal faces; MTCNN is better. Heavy compression/low resolution hurts.
- Output is a probability, not proof; do not use it as sole evidence against a person.
- Lightweight GAN-image datasets test a different problem from face-swap videos.

## 13. Future scope
Temporal models (LSTM / video transformers), frequency-domain features, audio-visual consistency, larger backbones/ensembles,
cross-dataset training, probability calibration, explainability (Grad-CAM), a web API for deployment.

## 14. References
1. Rossler et al., *FaceForensics++: Learning to Detect Manipulated Facial Images*, ICCV 2019.
2. Li et al., *Celeb-DF: A Large-scale Challenging Dataset for DeepFake Forensics*, CVPR 2020.
3. Dolhansky et al., *The DeepFake Detection Challenge (DFDC) Dataset*, 2020.
4. Tan & Le, *EfficientNet: Rethinking Model Scaling for CNNs*, ICML 2019.
5. Zhang et al., *Joint Face Detection and Alignment using Multi-task Cascaded CNNs (MTCNN)*, 2016.
6. Paszke et al., *PyTorch*, NeurIPS 2019; OpenCV library documentation.

## Documents for submission (in `docs/`)
`ABSTRACT.md`, `PROJECT_REPORT.md`, `VIVA_QUESTIONS.md`, `FACULTY_EXPLANATION.md`, `architecture_diagram.png`, `flowchart.png`.
