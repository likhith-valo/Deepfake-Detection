"""
config.py - central settings for DeepGuard AI.

Every other module imports its settings from here, so if you want to change
the image size, learning rate, folders etc. you only edit this one file.
"""
from pathlib import Path

# --------------------------------------------------------------------------
# Folders
# --------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
REAL_DIR = DATA_DIR / "real"            # extracted REAL face crops
FAKE_DIR = DATA_DIR / "fake"            # extracted FAKE face crops
SPLIT_CSV = DATA_DIR / "splits.csv"     # train/val/test table (created by preprocess)
WEIGHTS_DIR = BASE_DIR / "weights"
REPORTS_DIR = BASE_DIR / "reports"
BEST_WEIGHTS = WEIGHTS_DIR / "deepguard_best.pth"   # written by training

# --------------------------------------------------------------------------
# Labels.  FAKE is the "positive" class, so the model outputs P(FAKE).
# --------------------------------------------------------------------------
LABEL_REAL = 0
LABEL_FAKE = 1
CLASS_NAMES = ["REAL", "FAKE"]

# --------------------------------------------------------------------------
# Image / face preprocessing
# --------------------------------------------------------------------------
IMAGE_SIZE = 224                          # EfficientNet-B0 default input size
IMAGENET_MEAN = (0.485, 0.456, 0.406)     # normalisation used by the pretrained weights
IMAGENET_STD = (0.229, 0.224, 0.225)

FACE_DETECTOR = "auto"      # "auto" (MTCNN if installed, else OpenCV Haar), "mtcnn" or "haar"
FACE_MARGIN = 0.25          # extra context around the detected face box
MIN_FACE_SIZE = 40          # ignore faces smaller than this many pixels
MIN_FACE_CONFIDENCE = 0.90  # MTCNN only: ignore low-confidence detections

# --------------------------------------------------------------------------
# Dataset split (done per *group*, e.g. per video, to avoid data leakage)
# --------------------------------------------------------------------------
SEED = 42
TRAIN_RATIO = 0.70
VAL_RATIO = 0.15
TEST_RATIO = 0.15
FRAMES_PER_VIDEO_TRAIN = 10   # faces extracted per video when building the dataset

# --------------------------------------------------------------------------
# Training
# --------------------------------------------------------------------------
BATCH_SIZE = 32
EPOCHS = 10
LEARNING_RATE = 1e-4
WEIGHT_DECAY = 1e-4
DROPOUT = 0.3
FREEZE_BACKBONE_EPOCHS = 1     # first epoch(s) train only the new classifier head
EARLY_STOPPING_PATIENCE = 4    # stop if val loss has not improved for this many epochs
NUM_WORKERS = 2                # set to 0 if DataLoader gives problems (e.g. on Windows)

# --------------------------------------------------------------------------
# Inference
# --------------------------------------------------------------------------
DECISION_THRESHOLD = 0.5       # P(FAKE) >= threshold  ->  FAKE
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
VIDEO_EXTENSIONS = {".mp4", ".avi", ".mov"}
VIDEO_FRAME_INTERVAL_SEC = 1.0  # analyse one frame every N seconds
VIDEO_MAX_FRAMES = 40           # hard cap on analysed frames per video (keeps CPU time low)


def ensure_dirs():
    """Create the data/weights/reports folders if they do not exist."""
    for folder in (REAL_DIR, FAKE_DIR, WEIGHTS_DIR, REPORTS_DIR):
        folder.mkdir(parents=True, exist_ok=True)
