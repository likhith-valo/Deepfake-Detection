"""
face_detection.py - find faces in an RGB image (a numpy array).

Two back-ends:
  * MTCNN  (package `facenet-pytorch`) - deep-learning detector, more accurate.
  * Haar cascade (ships inside OpenCV)  - classic detector, always available.
"auto" uses MTCNN if it is installed and silently falls back to Haar otherwise.
"""
from pathlib import Path

import cv2
import numpy as np

import config


def crop_with_margin(image, box, margin=config.FACE_MARGIN):
    """Cut a (roughly square) crop around `box` = (x1, y1, x2, y2) with extra margin."""
    h, w = image.shape[:2]
    x1, y1, x2, y2 = box
    cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
    side = max(x2 - x1, y2 - y1) * (1.0 + margin)
    nx1, ny1 = int(max(0, cx - side / 2)), int(max(0, cy - side / 2))
    nx2, ny2 = int(min(w, cx + side / 2)), int(min(h, cy + side / 2))
    return image[ny1:ny2, nx1:nx2]


HAAR_NAME = "haarcascade_frontalface_default.xml"
HAAR_URL = ("https://raw.githubusercontent.com/opencv/opencv/4.x/data/haarcascades/"
            + HAAR_NAME)


def _find_haar_cascade():
    """
    Locate the Haar cascade XML.  Standard opencv-python 4.x wheels include it.
    Some builds (e.g. OpenCV 5.x wheels) do not, so we also look in weights/ and,
    as a last resort, download this one small file from OpenCV's GitHub into weights/.
    """
    candidates = []
    data_dir = getattr(getattr(cv2, "data", None), "haarcascades", None)
    if data_dir:
        candidates.append(Path(data_dir) / HAAR_NAME)
    candidates.append(config.WEIGHTS_DIR / HAAR_NAME)
    for c in candidates:
        if c.is_file():
            return c

    target = config.WEIGHTS_DIR / HAAR_NAME
    try:
        import urllib.request
        config.WEIGHTS_DIR.mkdir(parents=True, exist_ok=True)
        print(f"Haar cascade not bundled with this OpenCV; downloading to {target} ...")
        urllib.request.urlretrieve(HAAR_URL, target)
        return target
    except Exception as err:
        raise RuntimeError(
            "No face detector available. Either:\n"
            "  1) pip install \"opencv-python<5\" (its wheel includes the Haar cascade), or\n"
            "  2) pip install facenet-pytorch --no-deps (MTCNN detector), or\n"
            f"  3) manually download {HAAR_URL}\n     and save it as {target}\n"
            f"(automatic download failed: {err})") from err


class FaceDetector:
    def __init__(self, backend=None, device="cpu"):
        backend = backend or config.FACE_DETECTOR
        self.backend = None
        self._mtcnn = None
        self._cascade = None

        if backend in ("auto", "mtcnn"):
            try:
                from facenet_pytorch import MTCNN
                self._mtcnn = MTCNN(keep_all=True, device=device,
                                    min_face_size=config.MIN_FACE_SIZE)
                self.backend = "mtcnn"
            except Exception as err:   # not installed / failed to initialise
                if backend == "mtcnn":
                    raise RuntimeError(
                        "MTCNN requested but facenet-pytorch could not be loaded. "
                        "Install it (pip install facenet-pytorch --no-deps) or use "
                        "FACE_DETECTOR='haar' in config.py.") from err

        if self.backend is None:
            cascade_file = _find_haar_cascade()
            self._cascade = cv2.CascadeClassifier(str(cascade_file))
            if self._cascade.empty():
                raise RuntimeError(f"Could not load Haar cascade file: {cascade_file}")
            self.backend = "haar"

    # ------------------------------------------------------------------
    def detect(self, image_rgb):
        """
        Returns a list (largest face first) of dicts:
          {"box": [x1, y1, x2, y2], "confidence": float or None, "face": RGB crop}
        Haar does not give a confidence score, so it is None there (not invented).
        """
        boxes = self._detect_mtcnn(image_rgb) if self.backend == "mtcnn" else self._detect_haar(image_rgb)
        faces = []
        for box, conf in boxes:
            crop = crop_with_margin(image_rgb, box)
            if crop.size == 0:
                continue
            faces.append({"box": [int(v) for v in box], "confidence": conf, "face": crop})
        faces.sort(key=lambda f: (f["box"][2] - f["box"][0]) * (f["box"][3] - f["box"][1]), reverse=True)
        return faces

    def _detect_mtcnn(self, image_rgb):
        from PIL import Image
        boxes, probs = self._mtcnn.detect(Image.fromarray(image_rgb))
        results = []
        if boxes is None:
            return results
        for box, p in zip(boxes, probs):
            if p is None or p < config.MIN_FACE_CONFIDENCE:
                continue
            results.append((box, float(p)))
        return results

    def _detect_haar(self, image_rgb):
        h, w = image_rgb.shape[:2]
        scale = 1.0
        small = image_rgb
        if max(h, w) > 1000:                       # shrink big images -> faster
            scale = 1000.0 / max(h, w)
            small = cv2.resize(image_rgb, (int(w * scale), int(h * scale)))
        gray = cv2.equalizeHist(cv2.cvtColor(small, cv2.COLOR_RGB2GRAY))
        min_size = max(20, int(config.MIN_FACE_SIZE * scale))
        found = self._cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5,
                                               minSize=(min_size, min_size))
        results = []
        for (x, y, fw, fh) in found:
            box = [x / scale, y / scale, (x + fw) / scale, (y + fh) / scale]
            results.append((box, None))
        return results
