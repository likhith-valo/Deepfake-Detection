"""
image_detection.py - REAL / FAKE decision for a single image.

Pipeline:  validate -> load -> detect faces -> crop -> model -> aggregate

`predictor` is any object with .predict(list_of_rgb_faces) -> list of P(FAKE)
(normally models.model_loader.DeepfakePredictor).
"""
from pathlib import Path

import cv2
import numpy as np

import config


def validate_image(image_path):
    """Check the file exists, has a supported extension and can be decoded. Returns RGB array."""
    path = Path(image_path)
    if not path.is_file():
        raise FileNotFoundError(f"Image not found: {path}")
    if path.suffix.lower() not in config.IMAGE_EXTENSIONS:
        raise ValueError(f"Unsupported image type '{path.suffix}'. "
                         f"Supported: {sorted(config.IMAGE_EXTENSIONS)}")
    bgr = cv2.imread(str(path))
    if bgr is None:
        raise ValueError(f"File could not be read as an image (corrupt?): {path}")
    h, w = bgr.shape[:2]
    if min(h, w) < 32:
        raise ValueError(f"Image too small ({w}x{h}); need at least 32x32 pixels.")
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def detect_image(image_path, predictor, detector, threshold=None):
    """Analyse one image and return a result dictionary (JSON-friendly)."""
    threshold = config.DECISION_THRESHOLD if threshold is None else threshold
    image_rgb = validate_image(image_path)
    faces = detector.detect(image_rgb)

    result = {
        "media_type": "image",
        "path": str(image_path),
        "image_size": [int(image_rgb.shape[1]), int(image_rgb.shape[0])],
        "face_detector": detector.backend,
        "threshold": threshold,
        "num_faces": len(faces),
        "faces": [],
    }

    if not faces:
        result.update(overall_label="NO_FACE_DETECTED", overall_fake_probability=None,
                      overall_confidence=None,
                      summary="No face was detected, so the image cannot be classified.")
        return result

    probs = predictor.predict([f["face"] for f in faces])
    for i, (face, p) in enumerate(zip(faces, probs), start=1):
        p = float(p)
        label = "FAKE" if p >= threshold else "REAL"
        result["faces"].append({
            "face_index": i,
            "box": face["box"],
            "detector_confidence": face["confidence"],
            "fake_probability": round(p, 4),
            "label": label,
            "confidence": round(p if label == "FAKE" else 1 - p, 4),
        })

    # Image-level rule: if ANY face looks manipulated, the image is flagged FAKE.
    worst = max(f["fake_probability"] for f in result["faces"])
    overall = "FAKE" if worst >= threshold else "REAL"
    result["overall_label"] = overall
    result["overall_fake_probability"] = worst
    result["overall_confidence"] = round(worst if overall == "FAKE" else 1 - worst, 4)
    n_fake = sum(f["label"] == "FAKE" for f in result["faces"])
    result["summary"] = (f"{len(faces)} face(s) analysed, {n_fake} flagged as FAKE. "
                         f"Overall verdict: {overall} "
                         f"(P(fake)={worst:.2%}, confidence {result['overall_confidence']:.2%}).")
    return result


def save_annotated_image(image_path, result, out_path):
    """Draw a coloured box + label around each analysed face and save the picture."""
    bgr = cv2.imread(str(image_path))
    for f in result.get("faces", []):
        x1, y1, x2, y2 = f["box"]
        color = (0, 0, 255) if f["label"] == "FAKE" else (0, 180, 0)   # BGR
        cv2.rectangle(bgr, (x1, y1), (x2, y2), color, 2)
        text = f"{f['label']} {f['fake_probability']:.0%}"
        cv2.putText(bgr, text, (x1, max(15, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_path), bgr)
    return str(out_path)
