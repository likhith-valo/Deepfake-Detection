"""
video_detection.py - REAL / FAKE decision for a video.

To keep CPU time low we do NOT analyse every frame.  We look at one frame every
`interval_sec` seconds (and never more than `max_frames` frames in total, spread
over the whole video).  Each sampled frame is processed like an image.

Frame-level score : highest P(FAKE) among the faces in that frame.
Video-level score : mean of the frame-level scores (over frames that contain a face).
"""
import math
from pathlib import Path

import cv2

import config


def format_timestamp(seconds):
    return f"{int(seconds // 60):02d}:{seconds % 60:04.1f}"


def validate_video(video_path):
    path = Path(video_path)
    if not path.is_file():
        raise FileNotFoundError(f"Video not found: {path}")
    if path.suffix.lower() not in config.VIDEO_EXTENSIONS:
        raise ValueError(f"Unsupported video type '{path.suffix}'. "
                         f"Supported: {sorted(config.VIDEO_EXTENSIONS)}")
    return path


def analyze_video(video_path, predictor, detector, interval_sec=None,
                  max_frames=None, threshold=None):
    interval_sec = interval_sec or config.VIDEO_FRAME_INTERVAL_SEC
    max_frames = max_frames or config.VIDEO_MAX_FRAMES
    threshold = config.DECISION_THRESHOLD if threshold is None else threshold
    path = validate_video(video_path)

    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise ValueError(f"OpenCV could not open the video (corrupt or unsupported codec): {path}")

    fps = cap.get(cv2.CAP_PROP_FPS)
    fps_assumed = False
    if not fps or fps != fps or fps <= 0:           # 0, None or NaN
        fps, fps_assumed = 25.0, True
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)

    # Choose the step (in frames) between analysed frames.
    step = max(1, int(round(fps * interval_sec)))
    if total_frames > 0:
        step = max(step, int(math.ceil(total_frames / max_frames)))   # spread over whole video

    frame_results = []
    frame_idx = 0
    sampled = 0
    while True:
        if not cap.grab():                         # grab() is cheap; decode only sampled frames
            break
        if frame_idx % step == 0:
            ok, frame_bgr = cap.retrieve()
            if ok:
                frame_results.append(_analyse_frame(frame_bgr, frame_idx, fps,
                                                    predictor, detector, threshold))
                sampled += 1
                if sampled >= max_frames:
                    break
        frame_idx += 1
    cap.release()

    return _summarise(path, frame_results, fps, fps_assumed, total_frames,
                      step, interval_sec, threshold, detector.backend)


def _analyse_frame(frame_bgr, frame_idx, fps, predictor, detector, threshold):
    rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    faces = detector.detect(rgb)
    ts = frame_idx / fps
    entry = {"frame_index": frame_idx, "timestamp_sec": round(ts, 2),
             "timestamp": format_timestamp(ts), "num_faces": len(faces),
             "fake_probability": None, "label": "NO_FACE"}
    if faces:
        probs = predictor.predict([f["face"] for f in faces])
        p = float(max(probs))
        entry["fake_probability"] = round(p, 4)
        entry["label"] = "FAKE" if p >= threshold else "REAL"
    return entry


def _summarise(path, frames, fps, fps_assumed, total_frames, step, interval_sec,
               threshold, backend):
    with_faces = [f for f in frames if f["fake_probability"] is not None]
    result = {
        "media_type": "video",
        "path": str(path),
        "fps": round(fps, 2),
        "fps_assumed": fps_assumed,
        "total_frames": total_frames,
        "duration_sec": round(total_frames / fps, 2) if total_frames > 0 else None,
        "frame_step": step,
        "requested_interval_sec": interval_sec,
        "face_detector": backend,
        "threshold": threshold,
        "frames_analysed": len(frames),
        "frames_with_faces": len(with_faces),
        "frame_results": frames,
    }

    if not with_faces:
        result.update(overall_label="INCONCLUSIVE", overall_fake_probability=None,
                      overall_confidence=None, fake_frame_ratio=None,
                      suspicious_frames=[],
                      summary=f"{len(frames)} frame(s) analysed but no face was found, "
                              "so the video cannot be classified.")
        return result

    probs = [f["fake_probability"] for f in with_faces]
    mean_p = sum(probs) / len(probs)
    suspicious = [{"timestamp_sec": f["timestamp_sec"], "timestamp": f["timestamp"],
                   "frame_index": f["frame_index"], "fake_probability": f["fake_probability"]}
                  for f in with_faces if f["fake_probability"] >= threshold]
    verdict = "FAKE" if mean_p >= threshold else "REAL"

    result.update(
        overall_label=verdict,
        overall_fake_probability=round(mean_p, 4),
        overall_confidence=round(mean_p if verdict == "FAKE" else 1 - mean_p, 4),
        max_frame_fake_probability=max(probs),
        fake_frame_ratio=round(len(suspicious) / len(with_faces), 4),
        suspicious_frames=suspicious,
    )
    times = ", ".join(s["timestamp"] for s in suspicious[:10]) or "none"
    result["summary"] = (
        f"Analysed {len(frames)} sampled frame(s); {len(with_faces)} contained a face. "
        f"{len(suspicious)} frame(s) ({result['fake_frame_ratio']:.0%}) scored >= {threshold:.2f} for FAKE. "
        f"Mean P(fake) = {mean_p:.2%}. Overall verdict: {verdict} "
        f"(confidence {result['overall_confidence']:.2%}). "
        f"Suspicious timestamps: {times}{' ...' if len(suspicious) > 10 else ''}.")
    return result
