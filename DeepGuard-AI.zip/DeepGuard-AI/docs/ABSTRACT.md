# Abstract - DeepGuard AI: Deepfake Detection System Using Deep Learning (Group 9)

Deepfakes are AI-generated or AI-manipulated face images and videos that are increasingly realistic and are misused for
misinformation, fraud and harassment. This project presents DeepGuard AI, a Python backend that classifies facial
media as REAL or FAKE. The system detects faces in images and in frames sampled from videos (MTCNN, with an OpenCV Haar
cascade fallback), crops and normalises them to 224x224, and classifies each face with an EfficientNet-B0 convolutional
neural network. The network is pretrained on ImageNet and fine-tuned by transfer learning, with its final layer replaced
by a single sigmoid output giving the probability that a face is fake. Training uses binary cross-entropy with class
weighting, the AdamW optimiser, data augmentation and early stopping. To prevent data leakage, the dataset is split into
training, validation and test sets by video or identity group rather than by individual frame. For images, the system
reports a verdict and confidence per face; for videos, it reports frame-level predictions, a video-level verdict and the
timestamps of suspicious frames. Model quality is measured by accuracy, precision, recall, F1-score, ROC-AUC, a confusion
matrix and training curves, and is written to an evaluation report generated from the real test results. The system runs on CPU or GPU through a command-line
interface. Its limitations include reduced generalisation to unseen datasets and manipulation methods and the absence of
temporal modelling.

**Keywords:** deepfake detection, CNN, EfficientNet-B0, transfer learning, face detection, PyTorch, video analysis.
