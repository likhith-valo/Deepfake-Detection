# Project Explanation for Faculty - DeepGuard AI (Group 9)

## One-minute summary
DeepGuard AI is a deep-learning system that decides whether a face in an image or video is real or AI-manipulated. It finds faces,
prepares them, and feeds them to an EfficientNet-B0 network fine-tuned (transfer learning) on a public deepfake dataset. It outputs REAL/FAKE with a
confidence score, flags suspicious timestamps in videos, and evaluates itself with standard metrics.

## What is original / what we implemented
- Complete pipeline: dataset preparation, leakage-free splitting, training, evaluation, image and video inference, reports.
- Group-wise splitting with an automatic leakage check.
- Image rule (any fake face => FAKE) and video rule (mean of sampled frames + suspicious timestamps).
- Safety: the program refuses to predict without trained weights; never fabricates outputs.

## What we reused (and cite)
EfficientNet-B0 architecture and ImageNet weights (torchvision), MTCNN/OpenCV face detectors, public datasets (FaceForensics++, Celeb-DF, DFDC).

## How to demonstrate
1. Show `python -m unittest discover tests -v`.
2. Show data preparation and `data/splits.csv` (no group crosses splits).
3. Show training logs and `reports/training_curves.png`.
4. Run `python main.py evaluate` and open `reports/evaluation_report.md`.
5. Run `python main.py image sample.jpg --annotate` and `python main.py video sample.mp4`.

## Honest limitations to state
Results depend on the dataset and size we could train on; performance on other datasets or newer fakes will be lower; frame-level analysis only;
output is a probability, not proof.

## Learning outcomes
Transfer learning, CNN architectures, class imbalance, data leakage, evaluation metrics, computer-vision pipelines, reproducible ML engineering.
