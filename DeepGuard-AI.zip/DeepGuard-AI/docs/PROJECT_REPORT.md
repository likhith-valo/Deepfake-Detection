# Project Report - DeepGuard AI: Deepfake Detection System Using Deep Learning

**Group 9 | B.Tech Artificial Intelligence and Machine Learning**

> Results placeholders in section 8 must be filled from `reports/evaluation_report.md` after you train and evaluate.
> Do not report numbers you did not obtain.

## 1. Introduction
Advances in generative models (autoencoders, GANs, diffusion) make it easy to swap or synthesise faces. Such deepfakes threaten
trust in digital media. Automated detection is therefore an important applied AI problem.

## 2. Problem statement
Given an image or a video, decide whether the facial content is real or manipulated, and report a confidence score.

## 3. Objectives
Face detection and extraction; preprocessing; CNN-based classification using transfer learning; image and video analysis modules;
leakage-free dataset splitting; evaluation with standard metrics; report generation.

## 4. Literature review (summary)
- Early methods used hand-crafted cues: eye blinking, head-pose inconsistency, colour/texture artefacts.
- FaceForensics++ (2019) provided a large benchmark and showed CNNs (e.g. XceptionNet) outperform hand-crafted methods.
- Celeb-DF (2020) and the DFDC dataset (2020) offered harder, higher-quality fakes; detectors that do well on one dataset often drop on others.
- EfficientNet (2019) gave accurate CNNs at small size and is widely used in DFDC solutions.

## 5. System design
Modules: `detection/` (face detection, image and video analysis), `models/` (network and loader), `training/` (preprocessing, dataset, training,
evaluation), `utils/` (metrics, plots, reports), `main.py` (CLI). See `docs/architecture_diagram.png` and `docs/flowchart.png`.

## 6. Methodology
1. **Data preparation:** sample frames from videos; detect the largest face; crop with 25% margin; resize 224x224; store as JPEG.
2. **Splitting:** group-wise 70/15/15 split (GroupShuffleSplit, seed 42) with an assertion that no group crosses splits.
3. **Model:** torchvision EfficientNet-B0 (ImageNet weights); classifier replaced with Dropout(0.3) + Linear(1280, 1).
4. **Training:** BCEWithLogitsLoss (pos_weight = #real/#fake), AdamW (lr 1e-4, weight decay 1e-4), ReduceLROnPlateau, early stopping; first epoch backbone frozen.
5. **Augmentation:** horizontal flip, brightness/contrast, rotation up to 10 degrees, JPEG compression.
6. **Inference:** identical preprocessing; sigmoid probability; threshold 0.5.
7. **Aggregation:** image = max face probability; video = mean of frame maxima; suspicious frames listed.

## 7. Implementation
Python, PyTorch/torchvision, OpenCV, MTCNN (facenet-pytorch, optional), NumPy, Pandas, scikit-learn, Matplotlib, Seaborn.
CPU-compatible; GPU used automatically if present.

## 8. Testing and results
**Software tests** (`python -m unittest discover tests -v`): metrics against hand-computed values, leakage-free splitting,
preprocessing shapes, image/video pipeline plumbing, input validation.

**Model results (to be filled by you after running `python main.py evaluate`):**

| Metric | Test value |
|---|---|
| Accuracy | _fill from report_ |
| Precision | _fill from report_ |
| Recall | _fill from report_ |
| F1-score | _fill from report_ |
| ROC-AUC | _fill from report_ |

Insert `reports/confusion_matrix.png`, `roc_curve.png`, `training_curves.png` here.

## 9. Limitations
Dataset-specific generalisation, frame-level analysis only, detector misses on non-frontal faces (Haar), compression sensitivity, probabilistic output.

## 10. Conclusion
DeepGuard AI demonstrates a complete, reproducible deepfake-detection pipeline using transfer learning. Its measured performance depends on the dataset used and
must be reported from the generated evaluation report.

## 11. Future scope
Temporal models, frequency features, audio-visual cues, ensembles, cross-dataset evaluation, explainability (Grad-CAM), web deployment.

## 12. References
See README section 14.
