# 20 AIML Viva Questions and Answers - DeepGuard AI

**1. What is a deepfake?**
Media in which a person's face or voice is replaced or synthesised by AI (autoencoders, GANs, diffusion) so it looks real.

**2. What problem does your project solve?**
Binary classification of a face image/video as REAL or FAKE with a confidence score.

**3. What is a CNN and why use it here?**
A neural network that applies learnable convolution filters, detecting edges, textures and then complex patterns. Manipulation artefacts are local visual patterns, which CNNs learn well.

**4. What is EfficientNet-B0?**
A compact CNN (about 5M parameters) designed with compound scaling of depth, width and resolution, built from MBConv blocks. B0 is the baseline, input 224x224.

**5. What is transfer learning and why did you use it?**
Reusing a network pretrained on a large dataset (ImageNet) and adapting it to our task. It needs less data and training time and generalises better than training from scratch.

**6. What did you change in EfficientNet-B0?**
Replaced the 1000-class classifier with Dropout + Linear(1280 -> 1); one output logit, sigmoid gives P(FAKE).

**7. Why one output with sigmoid instead of two with softmax?**
Binary problem: one probability is enough; it pairs with binary cross-entropy. Two-class softmax is equivalent but redundant.

**8. Which loss function and why?**
`BCEWithLogitsLoss` - binary cross-entropy combined with sigmoid for numerical stability. We add `pos_weight` to compensate for class imbalance.

**9. Which optimiser?**
AdamW (Adam with decoupled weight decay) at learning rate 1e-4: adaptive, converges quickly, suitable for fine-tuning.

**10. Why freeze the backbone for the first epoch?**
The new head starts random; its large early gradients could damage pretrained features. Training the head first stabilises fine-tuning.

**11. What is data leakage and how did you avoid it?**
Information from test data influencing training. Frames of the same video are nearly identical, so we split by video/identity group, and the code asserts no group appears in two splits.

**12. Why use train, validation and test sets?**
Train: learn weights. Validation: choose best epoch/stop early. Test: final unbiased estimate, used only once at evaluation.

**13. What is overfitting and how do you reduce it?**
Memorising training data but failing on new data. We use augmentation, dropout, weight decay, early stopping and validation monitoring.

**14. What augmentations did you use and why?**
Flip, brightness/contrast, small rotation, JPEG compression - they add variety and mimic real-world conditions such as social-media compression.

**15. Explain precision, recall and F1 for this project.**
Precision: of media flagged FAKE, the share truly fake. Recall: of all fakes, the share we caught. F1: harmonic mean of both. FAKE is the positive class.

**16. Why is accuracy alone not enough?**
With imbalanced classes a model can score high accuracy by favouring the majority class; precision, recall, F1 and the confusion matrix reveal this.

**17. What is ROC-AUC?**
The ROC curve plots true-positive rate against false-positive rate across thresholds; AUC is the area under it (1.0 perfect, 0.5 random). It is threshold-independent.

**18. How do you classify a video?**
Sample frames at intervals, detect faces, get P(FAKE) per frame (max over faces), average them for the video verdict, and list frames above the threshold as suspicious timestamps.

**19. Why does a detector fail on a new dataset?**
Distribution shift: it may learn dataset-specific artefacts (compression, generation method) instead of general manipulation cues. Cross-dataset training and evaluation help.

**20. What are the limitations and the future scope?**
Limitations: generalisation, no temporal/audio cues, detector misses, probabilistic output. Future: temporal models, ensembles, frequency features, Grad-CAM explainability, deployment as an API.
