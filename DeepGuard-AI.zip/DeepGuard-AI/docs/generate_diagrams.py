"""
Draws the system architecture diagram and the detection flowchart as PNG files.
Run:  python docs/generate_diagrams.py     (needs only matplotlib)
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

OUT = Path(__file__).resolve().parent


def box(ax, x, y, w, h, text, color="#dbeafe", fs=9):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc=color, ec="#1e3a8a", lw=1.4))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, wrap=True)


def arrow(ax, x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color="#374151", lw=1.4))


def architecture():
    fig, ax = plt.subplots(figsize=(13, 7.5))
    ax.set_xlim(0, 13); ax.set_ylim(0, 7.5); ax.axis("off")
    ax.set_title("DeepGuard AI - System Architecture", fontsize=15, weight="bold")

    # Training pipeline (top row)
    ax.text(0.2, 6.75, "TRAINING PIPELINE (offline)", fontsize=10, weight="bold", color="#1e3a8a")
    steps = ["Public dataset\n(FF++ / Celeb-DF /\nDFDC / image sets)", "Frame sampling +\nface detection\n(MTCNN / Haar)",
             "Face crops\n224x224\ndata/real, data/fake", "Group-wise split\ntrain / val / test\n(no leakage)",
             "Fine-tune\nEfficientNet-B0\n(AdamW, BCE loss)", "Best weights\nweights/\ndeepguard_best.pth"]
    for i, t in enumerate(steps):
        x = 0.2 + i * 2.1
        box(ax, x, 5.2, 1.8, 1.3, t, "#fef3c7" if i < 4 else "#dcfce7", 8.5)
        if i:
            arrow(ax, x - 0.3, 5.85, x, 5.85)

    # Inference pipeline (middle)
    ax.text(0.2, 4.55, "INFERENCE PIPELINE (online)", fontsize=10, weight="bold", color="#1e3a8a")
    inf = ["Input\nimage / video\n(MP4, AVI, MOV)", "Validate file;\nsample frames\n(video only)", "Face detection\n+ crop with margin",
           "Preprocess:\nresize 224, normalise", "EfficientNet-B0\n(trained weights)\n-> P(FAKE)", "Aggregate:\nimage = worst face\nvideo = mean of frames",
           "REAL / FAKE\n+ confidence\n+ report"]
    for i, t in enumerate(inf):
        x = 0.1 + i * 1.82
        box(ax, x, 2.9, 1.55, 1.3, t, "#dbeafe" if i < 6 else "#dcfce7", 8)
        if i:
            arrow(ax, x - 0.27, 3.55, x, 3.55)

    # Evaluation (bottom)
    ax.text(0.2, 2.25, "EVALUATION", fontsize=10, weight="bold", color="#1e3a8a")
    ev = ["Held-out TEST split", "Model predictions", "Accuracy, Precision, Recall,\nF1, ROC-AUC, confusion matrix",
          "Graphs + evaluation_report.md\n(reports/)"]
    for i, t in enumerate(ev):
        x = 0.4 + i * 3.1
        box(ax, x, 0.7, 2.6, 1.2, t, "#fce7f3", 9)
        if i:
            arrow(ax, x - 0.5, 1.3, x, 1.3)
    fig.tight_layout()
    fig.savefig(OUT / "architecture_diagram.png", dpi=160)
    plt.close(fig)


def flowchart():
    fig, ax = plt.subplots(figsize=(8, 11))
    ax.set_xlim(0, 8); ax.set_ylim(0, 11); ax.axis("off")
    ax.set_title("DeepGuard AI - Detection Flowchart", fontsize=14, weight="bold")
    nodes = [
        (10.0, "START: user gives image or video path", "#e5e7eb"),
        (9.0, "Validate file (exists, supported type, readable)", "#dbeafe"),
        (8.0, "Video? -> sample 1 frame every N seconds (max frames cap)\nImage? -> use the image", "#dbeafe"),
        (7.0, "Detect faces (MTCNN, or Haar fallback)", "#dbeafe"),
        (6.0, "Any face found?", "#fef3c7"),
        (4.9, "Crop faces with margin -> resize 224x224 -> normalise", "#dbeafe"),
        (3.9, "EfficientNet-B0 -> sigmoid -> P(FAKE) per face", "#dbeafe"),
        (2.9, "Aggregate: image = highest face score\nvideo = mean frame score; list suspicious timestamps", "#dbeafe"),
        (1.9, "P(FAKE) >= threshold (0.5) ?", "#fef3c7"),
        (0.7, "Output FAKE / REAL + confidence; save report", "#dcfce7"),
    ]
    for y, t, c in nodes:
        box(ax, 1.4, y - 0.35, 5.2, 0.7, t, c, 9)
    for (y1, _, _), (y2, _, _) in zip(nodes, nodes[1:]):
        arrow(ax, 4, y1 - 0.37, 4, y2 + 0.37)
    box(ax, 6.9, 5.65, 1.0, 0.7, "NO\nface", "#fee2e2", 8)
    arrow(ax, 6.6, 6.0, 6.9, 6.0)
    ax.text(7.4, 5.4, "-> report\n'NO_FACE /\nINCONCLUSIVE'", ha="center", va="top", fontsize=7.5)
    ax.text(4.15, 5.55, "yes", fontsize=8)
    fig.tight_layout()
    fig.savefig(OUT / "flowchart.png", dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    architecture()
    flowchart()
    print("Saved architecture_diagram.png and flowchart.png in", OUT)
