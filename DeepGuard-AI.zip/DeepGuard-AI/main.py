"""
main.py - command-line entry point of DeepGuard AI.

Interactive menu:      python main.py
Command-line usage:    python main.py image  PATH [--annotate]
                       python main.py video  PATH [--interval 1.0] [--max-frames 40]
                       python main.py train  [--epochs 10] [--batch-size 32] [--no-pretrained]
                       python main.py evaluate [--split test]
                       python main.py prepare videos|dfdc|images|split ...   (dataset preparation)
"""
import argparse
import sys
from pathlib import Path

import config


# --------------------------------------------------------------------------
# Command handlers (heavy imports are inside so `--help` and the menu start fast)
# --------------------------------------------------------------------------
def cmd_image(path, weights=None, threshold=None, annotate=False, save_report=True):
    from detection.face_detection import FaceDetector
    from detection.image_detection import detect_image, save_annotated_image
    from models.model_loader import load_predictor
    from utils.report_generator import save_detection_report

    predictor = load_predictor(weights)
    detector = FaceDetector(device=str(predictor.device))
    result = detect_image(path, predictor, detector, threshold)
    print("\n" + result["summary"])
    for f in result["faces"]:
        print(f"  Face {f['face_index']}: {f['label']}  P(fake)={f['fake_probability']:.2%}")
    if annotate and result["faces"]:
        out = save_annotated_image(path, result, config.REPORTS_DIR / f"{Path(path).stem}_annotated.jpg")
        print(f"Annotated image: {out}")
    if save_report:
        j, t = save_detection_report(result)
        print(f"Report saved: {t}")
    return result


def cmd_video(path, weights=None, interval=None, max_frames=None, threshold=None, save_report=True):
    from detection.face_detection import FaceDetector
    from detection.video_detection import analyze_video
    from models.model_loader import load_predictor
    from utils.report_generator import save_detection_report

    predictor = load_predictor(weights)
    detector = FaceDetector(device=str(predictor.device))
    print("Analysing video (this can take a while on CPU)...")
    result = analyze_video(path, predictor, detector, interval, max_frames, threshold)
    print("\n" + result["summary"])
    if save_report:
        j, t = save_detection_report(result)
        print(f"Report saved: {t}")
    return result


def cmd_train(epochs=None, batch_size=None, pretrained=True):
    from training.train import train
    train(epochs=epochs, batch_size=batch_size, pretrained=pretrained)


def cmd_evaluate(split="test", weights=None):
    from training.evaluate import run_evaluation
    run_evaluation(weights_path=weights, split=split)


def safe_run(func, *args, **kwargs):
    """Run a command and turn expected problems into readable messages."""
    try:
        func(*args, **kwargs)
        return 0
    except (FileNotFoundError, ValueError, RuntimeError) as err:
        print(f"\nError: {err}")
    except ImportError as err:
        print(f"\nA required package is missing: {err}\nInstall everything with: pip install -r requirements.txt")
    return 1


# --------------------------------------------------------------------------
# Interactive menu
# --------------------------------------------------------------------------
def ask_path(prompt):
    return input(prompt).strip().strip('"').strip("'")


def interactive_menu():
    while True:
        print("\n=== DeepGuard AI - Deepfake Detection System (Group 9) ===")
        print("1. Detect deepfake in an image")
        print("2. Detect deepfake in a video")
        print("3. Train the model")
        print("4. Evaluate the model")
        print("5. Exit")
        choice = input("Select an option (1-5): ").strip()
        if choice == "1":
            p = ask_path("Image path: ")
            if p:
                safe_run(cmd_image, p, annotate=True)
        elif choice == "2":
            p = ask_path("Video path (.mp4/.avi/.mov): ")
            if p:
                iv = input(f"Seconds between analysed frames [{config.VIDEO_FRAME_INTERVAL_SEC}]: ").strip()
                safe_run(cmd_video, p, interval=float(iv) if iv else None)
        elif choice == "3":
            ep = input(f"Epochs [{config.EPOCHS}]: ").strip()
            safe_run(cmd_train, epochs=int(ep) if ep else None)
        elif choice == "4":
            safe_run(cmd_evaluate)
        elif choice == "5":
            print("Goodbye.")
            return
        else:
            print("Please enter a number from 1 to 5.")


# --------------------------------------------------------------------------
def build_parser():
    ap = argparse.ArgumentParser(description="DeepGuard AI - deepfake detection (run without arguments for the menu)")
    sub = ap.add_subparsers(dest="command")

    p = sub.add_parser("image", help="detect deepfake in an image")
    p.add_argument("path")
    p.add_argument("--weights"); p.add_argument("--threshold", type=float)
    p.add_argument("--annotate", action="store_true", help="save the image with boxes drawn")
    p.add_argument("--no-report", action="store_true")

    p = sub.add_parser("video", help="detect deepfake in a video")
    p.add_argument("path")
    p.add_argument("--weights"); p.add_argument("--threshold", type=float)
    p.add_argument("--interval", type=float, help="seconds between analysed frames")
    p.add_argument("--max-frames", type=int)
    p.add_argument("--no-report", action="store_true")

    p = sub.add_parser("train", help="train the model")
    p.add_argument("--epochs", type=int); p.add_argument("--batch-size", type=int)
    p.add_argument("--no-pretrained", action="store_true",
                   help="do NOT use ImageNet weights (only if they cannot be downloaded)")

    p = sub.add_parser("evaluate", help="evaluate the trained model")
    p.add_argument("--split", default="test", choices=["train", "val", "test"])
    p.add_argument("--weights")

    sub.add_parser("prepare", help="dataset preparation: see 'python main.py prepare videos -h'")
    return ap


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv and argv[0] == "prepare":                 # forward everything to the preprocess CLI
        from training.preprocess import main as prepare_main
        prepare_main(argv[1:])
        return 0

    args = build_parser().parse_args(argv)
    if args.command is None:
        interactive_menu()
        return 0
    if args.command == "image":
        return safe_run(cmd_image, args.path, args.weights, args.threshold, args.annotate, not args.no_report)
    if args.command == "video":
        return safe_run(cmd_video, args.path, args.weights, args.interval, args.max_frames,
                        args.threshold, not args.no_report)
    if args.command == "train":
        return safe_run(cmd_train, args.epochs, args.batch_size, not args.no_pretrained)
    if args.command == "evaluate":
        return safe_run(cmd_evaluate, args.split, args.weights)
    return 0


if __name__ == "__main__":
    sys.exit(main())
