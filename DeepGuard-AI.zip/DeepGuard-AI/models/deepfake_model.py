"""
deepfake_model.py - the neural network.

We use TRANSFER LEARNING: EfficientNet-B0 pretrained on ImageNet already knows
how to see edges, textures and shapes.  We keep that knowledge and only replace
the last layer, so that instead of 1000 ImageNet classes it outputs ONE number
(a "logit").  sigmoid(logit) = probability that the face is FAKE.
"""
import torch.nn as nn
from torchvision import models as tv_models

import config


class DeepfakeDetector(nn.Module):
    def __init__(self, pretrained: bool = True, dropout: float = config.DROPOUT):
        """
        pretrained=True  -> download ImageNet weights (needs internet the first time).
        pretrained=False -> random weights; used at inference because the real
                            weights are then loaded from our own checkpoint.
        """
        super().__init__()
        weights = tv_models.EfficientNet_B0_Weights.IMAGENET1K_V1 if pretrained else None
        self.backbone = tv_models.efficientnet_b0(weights=weights)

        # The original classifier is [Dropout, Linear(1280 -> 1000)].
        # Replace it with a binary head: Linear(1280 -> 1).
        in_features = self.backbone.classifier[1].in_features
        self.backbone.classifier = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(in_features, 1),
        )

    def forward(self, x):
        # x: (batch, 3, 224, 224)  ->  logits: (batch,)
        return self.backbone(x).view(-1)

    def set_backbone_trainable(self, trainable: bool):
        """Freeze / unfreeze the convolutional feature extractor (not the new head)."""
        for p in self.backbone.features.parameters():
            p.requires_grad = trainable
