"""
model_loader.py - load trained weights for inference.

DeepfakePredictor is the small object the detection modules use:
    probs = predictor.predict([face_rgb_1, face_rgb_2, ...])   # list of P(FAKE)
"""
from pathlib import Path

import torch

import config
from models.deepfake_model import DeepfakeDetector
from training.preprocess import faces_to_batch


def get_device(prefer=None):
    """Return a torch.device. Uses the GPU if available, otherwise the CPU."""
    if prefer:
        return torch.device(prefer)
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load_model(weights_path=None, device=None):
    """
    Build the network and load OUR trained weights into it.
    Raises FileNotFoundError if the model has not been trained yet - we never
    fall back to untrained / random predictions.
    """
    weights_path = Path(weights_path or config.BEST_WEIGHTS)
    device = device or get_device()
    if not weights_path.exists():
        raise FileNotFoundError(
            f"Trained weights not found: {weights_path}\n"
            "The model has not been trained yet. Prepare the dataset and run:\n"
            "    python main.py train"
        )
    checkpoint = torch.load(weights_path, map_location=device, weights_only=True)
    model = DeepfakeDetector(pretrained=False)      # weights come from the checkpoint
    model.load_state_dict(checkpoint["model_state"])
    model.to(device)
    model.eval()                                    # inference mode (no dropout)
    return model, checkpoint


class DeepfakePredictor:
    """Wraps a model + device: list of RGB face crops in, list of P(FAKE) out."""

    def __init__(self, model, device, checkpoint=None):
        self.model = model
        self.device = device
        self.checkpoint = checkpoint or {}

    @torch.no_grad()
    def predict(self, faces_rgb, batch_size=16):
        probs = []
        for i in range(0, len(faces_rgb), batch_size):
            batch = faces_to_batch(faces_rgb[i:i + batch_size]).to(self.device)
            logits = self.model(batch)
            probs.extend(torch.sigmoid(logits).cpu().tolist())
        return probs


def load_predictor(weights_path=None, device=None):
    device = device or get_device()
    model, checkpoint = load_model(weights_path, device)
    return DeepfakePredictor(model, device, checkpoint)
