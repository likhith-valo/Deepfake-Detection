"""
Tests that do NOT need PyTorch (data prep, splitting, metrics, face detection,
video/image plumbing).  Run from the project root:

    python -m unittest discover tests -v

IMPORTANT: DummyPredictor below is a TEST STUB used only to check the plumbing
(frame sampling, aggregation, report writing).  It is never used by main.py and
its outputs mean nothing about deepfakes.  Real model tests: test_torch_model.py.
"""
import sys
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config
from detection.face_detection import FaceDetector
from detection.image_detection import detect_image, validate_image
from detection.video_detection import analyze_video
from training import preprocess
from utils.metrics import compute_metrics
from utils.report_generator import format_detection_report, save_detection_report


class DummyPredictor:
    """Test stub: returns a fixed probability for every face."""
    def __init__(self, p=0.9):
        self.p = p

    def predict(self, faces):
        return [self.p] * len(faces)


class StubDetector:
    """Test stub: treats the WHOLE image as one face (or no face if no_face=True).
    Used only to check plumbing; real detection is tested in TestRealHaarDetector."""
    backend = "stub"

    def __init__(self, no_face=False):
        self.no_face = no_face

    def detect(self, rgb):
        if self.no_face:
            return []
        h, w = rgb.shape[:2]
        return [{"box": [0, 0, w, h], "confidence": None, "face": rgb}]


def astronaut_rgb():
    try:
        from skimage import data
        return data.astronaut()
    except Exception:
        return None


class TestMetrics(unittest.TestCase):
    def test_known_values(self):
        # preds at 0.5: [0, 1, 0, 1] vs truth [0, 0, 1, 1] -> TN=1 FP=1 FN=1 TP=1
        m = compute_metrics([0, 0, 1, 1], [0.1, 0.6, 0.4, 0.9])
        self.assertAlmostEqual(m["accuracy"], 0.5)
        self.assertAlmostEqual(m["precision"], 0.5)
        self.assertAlmostEqual(m["recall"], 0.5)
        self.assertAlmostEqual(m["f1_score"], 0.5)
        self.assertEqual(m["confusion_matrix"], [[1, 1], [1, 1]])
        self.assertAlmostEqual(m["roc_auc"], 0.75)

    def test_single_class_auc_is_none(self):
        self.assertIsNone(compute_metrics([1, 1], [0.7, 0.8])["roc_auc"])


class TestPreprocessHelpers(unittest.TestCase):
    def test_face_to_numpy_shape_and_range(self):
        face = (np.random.rand(97, 120, 3) * 255).astype(np.uint8)
        x = preprocess.face_to_numpy(face)
        self.assertEqual(x.shape, (3, config.IMAGE_SIZE, config.IMAGE_SIZE))
        self.assertEqual(x.dtype, np.float32)

    def test_group_key(self):
        self.assertEqual(preprocess.group_key("000_003", "video"), "000_003")
        self.assertEqual(preprocess.group_key("000_003", "identity"), "000")
        self.assertEqual(preprocess.group_key("id0_id16_0003", "identity"), "id0")
        self.assertEqual(preprocess.group_key("orig--fake", "video"), "orig")


class TestSplitNoLeakage(unittest.TestCase):
    def test_groups_never_cross_splits(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            (tmp / "real").mkdir(); (tmp / "fake").mkdir()
            img = np.zeros((32, 32, 3), np.uint8)
            for v in range(20):                         # 20 videos x 5 frames per class
                for f in range(5):
                    cv2.imwrite(str(tmp / "real" / f"r{v}__f{f:05d}.jpg"), img)
                    cv2.imwrite(str(tmp / "fake" / f"f{v}__f{f:05d}.jpg"), img)
            df = preprocess.build_splits("video", real_dir=tmp / "real", fake_dir=tmp / "fake",
                                         out_csv=tmp / "splits.csv")
            for g, sub in df.groupby("group"):
                self.assertEqual(sub["split"].nunique(), 1, f"group {g} leaked across splits")
            self.assertEqual(set(df["split"]), {"train", "val", "test"})


@unittest.skipIf(astronaut_rgb() is None, "scikit-image sample image not available")
class TestFaceAndMedia(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls.tmp.name)
        cls.img = astronaut_rgb()
        cls.img_path = cls.dir / "face.jpg"
        cv2.imwrite(str(cls.img_path), cv2.cvtColor(cls.img, cv2.COLOR_RGB2BGR))
        # 4-second synthetic video made of the same picture, 10 fps
        cls.vid_path = cls.dir / "clip.mp4"
        writer = cv2.VideoWriter(str(cls.vid_path), cv2.VideoWriter_fourcc(*"mp4v"), 10, (512, 512))
        for _ in range(40):
            writer.write(cv2.cvtColor(cls.img, cv2.COLOR_RGB2BGR))
        writer.release()
        cls.detector = StubDetector()

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_image_pipeline(self):
        r = detect_image(self.img_path, DummyPredictor(0.9), self.detector)
        self.assertEqual(r["overall_label"], "FAKE")
        self.assertGreaterEqual(r["num_faces"], 1)
        r2 = detect_image(self.img_path, DummyPredictor(0.1), self.detector)
        self.assertEqual(r2["overall_label"], "REAL")

    def test_no_face_image(self):
        blank = self.dir / "blank.png"
        cv2.imwrite(str(blank), np.full((200, 200, 3), 128, np.uint8))
        r = detect_image(blank, DummyPredictor(), StubDetector(no_face=True))
        self.assertEqual(r["overall_label"], "NO_FACE_DETECTED")

    def test_validation_errors(self):
        with self.assertRaises(FileNotFoundError):
            validate_image(self.dir / "nope.jpg")
        bad = self.dir / "bad.jpg"
        bad.write_text("not an image")
        with self.assertRaises(ValueError):
            validate_image(bad)

    def test_video_pipeline(self):
        r = analyze_video(self.vid_path, DummyPredictor(0.8), self.detector, interval_sec=1.0)
        self.assertEqual(r["overall_label"], "FAKE")
        self.assertEqual(r["frames_analysed"], 4)          # 40 frames @10fps, 1 per second
        self.assertEqual(len(r["suspicious_frames"]), r["frames_with_faces"])
        text = format_detection_report(r)
        self.assertIn("VERDICT", text)
        j, t = save_detection_report(r, self.dir)
        self.assertTrue(Path(j).exists() and Path(t).exists())

    def test_video_unsupported_extension(self):
        wrong = self.dir / "clip.mkv"
        wrong.write_bytes(b"x")
        with self.assertRaises(ValueError):
            analyze_video(wrong, DummyPredictor(), self.detector)

    def test_extract_faces_from_video(self):
        out = self.dir / "extracted"
        out.mkdir()
        n = preprocess.extract_faces_from_video(self.vid_path, self.detector, out, "clip", 5)
        self.assertGreaterEqual(n, 1)
        self.assertTrue(any(out.glob("clip__f*.jpg")))


@unittest.skipIf(astronaut_rgb() is None, "scikit-image sample image not available")
class TestRealHaarDetector(unittest.TestCase):
    """Real OpenCV Haar face detection (skipped if the cascade file is unavailable)."""

    def test_detects_face_in_photo(self):
        try:
            detector = FaceDetector("haar")
        except RuntimeError as err:
            self.skipTest(f"Haar cascade unavailable: {err}".splitlines()[0])
        faces = detector.detect(astronaut_rgb())
        self.assertGreaterEqual(len(faces), 1)
        self.assertEqual(faces[0]["face"].ndim, 3)

    def test_no_face_in_blank_image(self):
        try:
            detector = FaceDetector("haar")
        except RuntimeError as err:
            self.skipTest(f"Haar cascade unavailable: {err}".splitlines()[0])
        self.assertEqual(detector.detect(np.full((200, 200, 3), 128, np.uint8)), [])


if __name__ == "__main__":
    unittest.main()
