"""
Tests that need PyTorch + torchvision.  Skipped automatically if torch is missing.
They use random (untrained) weights ONLY to check shapes and save/load plumbing -
the outputs have no meaning as deepfake predictions.

    python -m unittest tests.test_torch_model -v
"""
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

try:
    import torch
    HAVE_TORCH = True
except ImportError:
    HAVE_TORCH = False


@unittest.skipUnless(HAVE_TORCH, "PyTorch not installed")
class TestModel(unittest.TestCase):
    def test_forward_shape(self):
        from models.deepfake_model import DeepfakeDetector
        m = DeepfakeDetector(pretrained=False).eval()
        out = m(torch.randn(2, 3, 224, 224))
        self.assertEqual(tuple(out.shape), (2,))

    def test_checkpoint_roundtrip_and_predictor(self):
        import config
        from models.deepfake_model import DeepfakeDetector
        from models.model_loader import load_predictor
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "w.pth"
            torch.save({"model_state": DeepfakeDetector(pretrained=False).state_dict(),
                        "epoch": 1}, path)
            predictor = load_predictor(path)
            faces = [(np.random.rand(100, 100, 3) * 255).astype(np.uint8) for _ in range(3)]
            probs = predictor.predict(faces)
            self.assertEqual(len(probs), 3)
            self.assertTrue(all(0.0 <= p <= 1.0 for p in probs))

    def test_missing_weights_raises(self):
        from models.model_loader import load_model
        with self.assertRaises(FileNotFoundError):
            load_model("does_not_exist.pth")


if __name__ == "__main__":
    unittest.main()
