"""
dataset.py - PyTorch Dataset / DataLoader for the face crops listed in data/splits.csv.

Training images get light AUGMENTATION (random flip, brightness/contrast, small
rotation, JPEG compression) so the model does not over-fit.  Validation and test
images are NOT augmented.
"""
import random

import cv2
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset

import config
from training.preprocess import face_to_numpy


def augment_face(rgb):
    """Random, mild augmentation of an RGB uint8 image."""
    if random.random() < 0.5:                                   # horizontal flip
        rgb = rgb[:, ::-1]
    rgb = np.ascontiguousarray(rgb)

    if random.random() < 0.5:                                   # brightness / contrast
        alpha = random.uniform(0.85, 1.15)                      # contrast
        beta = random.uniform(-15, 15)                          # brightness
        rgb = np.clip(rgb.astype(np.float32) * alpha + beta, 0, 255).astype(np.uint8)

    if random.random() < 0.3:                                   # small rotation
        h, w = rgb.shape[:2]
        m = cv2.getRotationMatrix2D((w / 2, h / 2), random.uniform(-10, 10), 1.0)
        rgb = cv2.warpAffine(rgb, m, (w, h), borderMode=cv2.BORDER_REFLECT)

    if random.random() < 0.3:                                   # JPEG compression (like social media)
        quality = random.randint(60, 95)
        ok, enc = cv2.imencode(".jpg", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR),
                               [cv2.IMWRITE_JPEG_QUALITY, quality])
        if ok:
            rgb = cv2.cvtColor(cv2.imdecode(enc, cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)
    return rgb


class FaceDataset(Dataset):
    def __init__(self, split, csv_path=None, augment=False):
        df = pd.read_csv(csv_path or config.SPLIT_CSV)
        self.df = df[df["split"] == split].reset_index(drop=True)
        if self.df.empty:
            raise ValueError(f"No samples in split '{split}'. Did you run the 'split' step?")
        self.augment = augment

    def __len__(self):
        return len(self.df)

    @property
    def labels(self):
        return self.df["label"].tolist()

    def __getitem__(self, i):
        row = self.df.iloc[i]
        path = config.BASE_DIR / row["path"]
        bgr = cv2.imread(str(path))
        if bgr is None:
            raise RuntimeError(f"Cannot read image: {path}")
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        if self.augment:
            rgb = augment_face(rgb)
        x = torch.from_numpy(face_to_numpy(rgb))
        y = torch.tensor(float(row["label"]), dtype=torch.float32)
        return x, y


def get_dataloader(split, batch_size=None, num_workers=None, csv_path=None):
    batch_size = batch_size or config.BATCH_SIZE
    num_workers = config.NUM_WORKERS if num_workers is None else num_workers
    ds = FaceDataset(split, csv_path=csv_path, augment=(split == "train"))
    return DataLoader(ds, batch_size=batch_size, shuffle=(split == "train"),
                      num_workers=num_workers, pin_memory=torch.cuda.is_available())
