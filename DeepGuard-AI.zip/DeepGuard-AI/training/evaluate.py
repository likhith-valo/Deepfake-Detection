"""
evaluate.py - measure the trained model on a held-out split (default: TEST).

The test split was never used for training or for choosing the best epoch,
so these numbers are an honest estimate of performance on unseen data
(from the same dataset).
"""
import json

import torch

import config
from models.model_loader import get_device, load_model
from training.dataset import get_dataloader
from utils.metrics import compute_metrics
from utils.report_generator import generate_evaluation_report, save_json
from utils.visualization import plot_confusion_matrix, plot_roc_curve, plot_training_curves


@torch.no_grad()
def collect_predictions(model, loader, device):
    y_true, y_prob = [], []
    for x, y in loader:
        probs = torch.sigmoid(model(x.to(device))).cpu().tolist()
        y_prob.extend(probs)
        y_true.extend(y.tolist())
    return y_true, y_prob


def run_evaluation(weights_path=None, split="test", batch_size=None, num_workers=None):
    config.ensure_dirs()
    device = get_device()
    model, checkpoint = load_model(weights_path, device)     # raises if not trained
    loader = get_dataloader(split, batch_size, num_workers)
    print(f"Evaluating on '{split}' split: {len(loader.dataset)} images (device: {device})")

    y_true, y_prob = collect_predictions(model, loader, device)
    metrics = compute_metrics(y_true, y_prob)

    out = config.REPORTS_DIR
    figures = [plot_confusion_matrix(metrics["confusion_matrix"], out / "confusion_matrix.png",
                                     title=f"Confusion matrix ({split})")]
    if metrics["roc_auc"] is not None:
        figures.append(plot_roc_curve(y_true, y_prob, metrics["roc_auc"], out / "roc_curve.png"))

    history = None
    hist_file = out / "training_history.json"
    if hist_file.exists():
        history = json.loads(hist_file.read_text())
        figures.append(plot_training_curves(history, out / "training_curves.png"))

    save_json(metrics, out / "evaluation_metrics.json")
    report = generate_evaluation_report(metrics, split, history, checkpoint, figures)

    print(f"\nAccuracy  : {metrics['accuracy']:.4f}")
    print(f"Precision : {metrics['precision']:.4f}")
    print(f"Recall    : {metrics['recall']:.4f}")
    print(f"F1-score  : {metrics['f1_score']:.4f}")
    print(f"ROC-AUC   : {metrics['roc_auc']}")
    print(f"Confusion matrix [[TN, FP], [FN, TP]]: {metrics['confusion_matrix']}")
    print(f"\nFull report: {report}")
    return metrics
