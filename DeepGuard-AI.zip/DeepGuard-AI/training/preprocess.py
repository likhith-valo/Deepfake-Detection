"""
preprocess.py - (1) turn a raw dataset into face crops, (2) split it, (3) tensor helpers.

Command line (run from the project root):

  # FaceForensics++ / Celeb-DF style: one folder of real videos, one of fake videos
  python -m training.preprocess videos --real-dir PATH --fake-dir PATH --max-videos 100

  # Kaggle DFDC sample: one folder of videos + metadata.json (labels + 'original')
  python -m training.preprocess dfdc --video-dir PATH

  # Image datasets (e.g. "140k Real and Fake Faces"): folders of images
  python -m training.preprocess images --real-dir PATH --fake-dir PATH --max-images 5000 --no-detect

  # Then create the train / val / test table (ALWAYS done after extraction)
  python -m training.preprocess split --group-mode identity

WHY SPLIT BY GROUP?  Frames from the same video look almost identical.  If one
frame lands in train and another in test, the model just "remembers" the video
and test accuracy becomes fake-high (DATA LEAKAGE).  So whole groups (videos /
identities) go to exactly one of train / val / test.

NOTE: this module avoids importing torch at the top so dataset preparation works
without it; torch is imported only inside faces_to_batch().
"""
import argparse
import json
import random
import sys
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

import config


# ==========================================================================
# Part 1 - tensor helpers (shared by training AND inference => identical preprocessing)
# ==========================================================================
def resize_face(face_rgb, size=config.IMAGE_SIZE):
    interp = cv2.INTER_AREA if face_rgb.shape[0] > size else cv2.INTER_LINEAR
    return cv2.resize(face_rgb, (size, size), interpolation=interp)


def face_to_numpy(face_rgb):
    """RGB uint8 face of any size -> float32 array (3, 224, 224), ImageNet-normalised."""
    x = resize_face(face_rgb).astype(np.float32) / 255.0
    x = (x - np.array(config.IMAGENET_MEAN, dtype=np.float32)) / np.array(config.IMAGENET_STD, dtype=np.float32)
    return np.ascontiguousarray(x.transpose(2, 0, 1))


def faces_to_batch(faces_rgb):
    """List of RGB faces -> torch tensor (N, 3, 224, 224)."""
    import torch
    return torch.from_numpy(np.stack([face_to_numpy(f) for f in faces_rgb]))


# ==========================================================================
# Part 2 - extracting faces
# ==========================================================================
def _largest_face(detector, rgb):
    faces = detector.detect(rgb)
    return faces[0]["face"] if faces else None      # detector sorts largest first


def _save_face(face_rgb, out_path):
    cv2.imwrite(str(out_path), cv2.cvtColor(resize_face(face_rgb), cv2.COLOR_RGB2BGR),
                [cv2.IMWRITE_JPEG_QUALITY, 95])


def extract_faces_from_video(video_path, detector, out_dir, out_id, frames_per_video):
    """Save up to `frames_per_video` face crops (evenly spaced frames). Returns #saved."""
    cap = cv2.VideoCapture(str(video_path))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    if not cap.isOpened() or total <= 0:
        cap.release()
        print(f"  [skip] cannot read video: {video_path}")
        return 0
    indices = np.unique(np.linspace(0, total - 1, frames_per_video).astype(int))
    saved = 0
    for idx in indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(idx))
        ok, frame = cap.read()
        if not ok:
            continue
        face = _largest_face(detector, cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        if face is None or face.size == 0:
            continue
        _save_face(face, Path(out_dir) / f"{out_id}__f{int(idx):05d}.jpg")
        saved += 1
    cap.release()
    return saved


def list_files(folder, extensions):
    return sorted(p for p in Path(folder).rglob("*") if p.is_file() and p.suffix.lower() in extensions)


def process_videos(video_dir, label_name, detector, frames_per_video, max_videos=None, seed=config.SEED):
    out_dir = config.REAL_DIR if label_name == "real" else config.FAKE_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    videos = list_files(video_dir, config.VIDEO_EXTENSIONS)
    random.Random(seed).shuffle(videos)
    if max_videos:
        videos = videos[:max_videos]
    print(f"[{label_name}] {len(videos)} video(s) from {video_dir}")
    total = 0
    for i, v in enumerate(videos, 1):
        n = extract_faces_from_video(v, detector, out_dir, v.stem, frames_per_video)
        total += n
        print(f"  {i}/{len(videos)} {v.name}: {n} face(s)")
    print(f"[{label_name}] saved {total} face image(s) to {out_dir}")


def process_dfdc(video_dir, detector, frames_per_video, max_videos=None, seed=config.SEED):
    """DFDC: metadata.json maps video -> {"label": "REAL"/"FAKE", "original": real_video}."""
    video_dir = Path(video_dir)
    meta_file = video_dir / "metadata.json"
    if not meta_file.exists():
        sys.exit(f"metadata.json not found in {video_dir}")
    meta = json.loads(meta_file.read_text())
    names = sorted(meta)
    random.Random(seed).shuffle(names)
    counts = {"REAL": 0, "FAKE": 0}
    for name in names:
        label = str(meta[name].get("label", "")).upper()
        if label not in counts or not (video_dir / name).exists():
            continue
        if max_videos and counts[label] >= max_videos:
            continue
        stem = Path(name).stem
        out_dir = config.REAL_DIR if label == "REAL" else config.FAKE_DIR
        out_dir.mkdir(parents=True, exist_ok=True)
        out_id = stem
        if label == "FAKE" and meta[name].get("original"):
            # "originalstem--fakestem": the split step groups a fake with its source video
            out_id = f"{Path(meta[name]['original']).stem}--{stem}"
        n = extract_faces_from_video(video_dir / name, detector, out_dir, out_id, frames_per_video)
        counts[label] += 1
        print(f"  {label} {name}: {n} face(s)")
    print(f"Processed videos: {counts}")


def process_images(image_dir, label_name, detector, max_images=None, seed=config.SEED):
    """Image datasets. detector=None -> images are already cropped faces, only resize."""
    out_dir = config.REAL_DIR if label_name == "real" else config.FAKE_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    images = list_files(image_dir, config.IMAGE_EXTENSIONS)
    random.Random(seed).shuffle(images)
    if max_images:
        images = images[:max_images]
    print(f"[{label_name}] {len(images)} image(s) from {image_dir}")
    saved = 0
    for p in images:
        bgr = cv2.imread(str(p))
        if bgr is None:
            continue
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        face = rgb if detector is None else _largest_face(detector, rgb)
        if face is None or face.size == 0:
            continue
        target = out_dir / f"{p.stem}.jpg"
        k = 1
        while target.exists():                      # avoid overwriting same-named files
            target = out_dir / f"{p.stem}-{k}.jpg"
            k += 1
        _save_face(face, target)
        saved += 1
    print(f"[{label_name}] saved {saved} face image(s) to {out_dir}")


# ==========================================================================
# Part 3 - train / val / test split WITHOUT leakage
# ==========================================================================
def group_key(video_id, mode):
    """
    video          : every video is its own group (DFDC fakes are grouped with their
                     original real video automatically via the 'orig--fake' naming).
    identity       : first token before '_' - FF++ '000_003' -> '000', Celeb-DF
                     'id0_id16_0003' -> 'id0'.  Keeps a person (and his/her fakes) together.
    ffpp-official  : same as identity, but then uses the OFFICIAL FaceForensics++
                     train/val/test json files (see build_splits).
    """
    base = video_id.split("--")[0]
    if mode in ("identity", "ffpp-official"):
        base = base.split("_")[0]
    return base


def _load_official_split(split_json_dir):
    """Read train.json / val.json / test.json (lists of id pairs) -> {id: split_name}."""
    mapping = {}
    for name in ("train", "val", "test"):
        f = Path(split_json_dir) / f"{name}.json"
        if not f.exists():
            sys.exit(f"Official split file missing: {f}")
        stack = [json.loads(f.read_text())]
        while stack:
            item = stack.pop()
            if isinstance(item, list):
                stack.extend(item)
            else:
                mapping[str(item)] = name
    return mapping


def build_splits(group_mode="video", split_json_dir=None, seed=config.SEED,
                 real_dir=None, fake_dir=None, out_csv=None):
    from sklearn.model_selection import GroupShuffleSplit

    real_dir = Path(real_dir or config.REAL_DIR)
    fake_dir = Path(fake_dir or config.FAKE_DIR)
    out_csv = Path(out_csv or config.SPLIT_CSV)

    rows = []
    for label, folder in ((config.LABEL_REAL, real_dir), (config.LABEL_FAKE, fake_dir)):
        for p in list_files(folder, config.IMAGE_EXTENSIONS):
            video_id = p.stem.split("__f")[0]
            try:
                rel = p.relative_to(config.BASE_DIR).as_posix()
            except ValueError:
                rel = str(p)                       # outside project folder (e.g. tests)
            rows.append({"path": rel, "label": label, "group": group_key(video_id, group_mode)})
    df = pd.DataFrame(rows)
    if df.empty or df["label"].nunique() < 2:
        sys.exit("Need face images in BOTH data/real and data/fake. Run the extraction step first.")

    if group_mode == "ffpp-official":
        mapping = _load_official_split(split_json_dir)
        df["split"] = df["group"].map(mapping)
        missing = int(df["split"].isna().sum())
        if missing:
            print(f"Warning: {missing} image(s) have an id not listed in the official split; dropped.")
        df = df.dropna(subset=["split"]).reset_index(drop=True)
    else:
        if df["group"].nunique() < 3:
            sys.exit("Need at least 3 different groups (videos/identities) to make 3 splits.")
        test_part = config.TEST_RATIO
        val_part = config.VAL_RATIO / (1.0 - config.TEST_RATIO)
        gss = GroupShuffleSplit(n_splits=1, test_size=test_part, random_state=seed)
        trainval_idx, test_idx = next(gss.split(df, groups=df["group"]))
        trainval = df.iloc[trainval_idx]
        gss2 = GroupShuffleSplit(n_splits=1, test_size=val_part, random_state=seed)
        tr_rel, val_rel = next(gss2.split(trainval, groups=trainval["group"]))
        df["split"] = ""
        df.loc[trainval.index[tr_rel], "split"] = "train"
        df.loc[trainval.index[val_rel], "split"] = "val"
        df.loc[df.index[test_idx], "split"] = "test"

    # ---- leakage check: no group may appear in two splits ----
    g = {s: set(df[df.split == s].group) for s in ("train", "val", "test")}
    assert not (g["train"] & g["val"] or g["train"] & g["test"] or g["val"] & g["test"]), \
        "DATA LEAKAGE: a group appears in more than one split!"

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)
    print(f"Wrote {out_csv}  (group mode: {group_mode}; no group appears in two splits)")
    print(df.groupby(["split", "label"]).size().unstack(fill_value=0)
            .rename(columns={0: "REAL", 1: "FAKE"}).to_string())
    for s in ("train", "val", "test"):
        if df[df.split == s].label.nunique() < 2:
            print(f"Warning: the '{s}' split contains only one class - add more data.")
    return df


# ==========================================================================
# Command line
# ==========================================================================
def main(argv=None):
    ap = argparse.ArgumentParser(description="DeepGuard AI dataset preparation")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add_common(p):
        p.add_argument("--detector", default=None, choices=["auto", "mtcnn", "haar"])

    p = sub.add_parser("videos", help="extract faces from folders of real/fake videos")
    p.add_argument("--real-dir"); p.add_argument("--fake-dir")
    p.add_argument("--frames-per-video", type=int, default=config.FRAMES_PER_VIDEO_TRAIN)
    p.add_argument("--max-videos", type=int, help="limit per class (lightweight dataset)")
    add_common(p)

    p = sub.add_parser("dfdc", help="extract faces from a DFDC folder with metadata.json")
    p.add_argument("--video-dir", required=True)
    p.add_argument("--frames-per-video", type=int, default=config.FRAMES_PER_VIDEO_TRAIN)
    p.add_argument("--max-videos", type=int, help="limit per class (DFDC is ~80%% fake)")
    add_common(p)

    p = sub.add_parser("images", help="process folders of real/fake images")
    p.add_argument("--real-dir"); p.add_argument("--fake-dir")
    p.add_argument("--max-images", type=int, help="limit per class")
    p.add_argument("--no-detect", action="store_true",
                   help="images are already cropped faces: just resize")
    add_common(p)

    p = sub.add_parser("split", help="create data/splits.csv (train/val/test, no leakage)")
    p.add_argument("--group-mode", default="video", choices=["video", "identity", "ffpp-official"])
    p.add_argument("--split-json-dir", help="folder with FF++ train.json/val.json/test.json")

    args = ap.parse_args(argv)
    config.ensure_dirs()

    if args.cmd == "split":
        build_splits(args.group_mode, args.split_json_dir)
        return

    from detection.face_detection import FaceDetector
    use_detector = not (args.cmd == "images" and args.no_detect)
    detector = FaceDetector(args.detector) if use_detector else None
    if detector:
        print(f"Face detector: {detector.backend}")

    if args.cmd == "videos":
        if not (args.real_dir or args.fake_dir):
            sys.exit("Give --real-dir and/or --fake-dir")
        if args.real_dir:
            process_videos(args.real_dir, "real", detector, args.frames_per_video, args.max_videos)
        if args.fake_dir:
            process_videos(args.fake_dir, "fake", detector, args.frames_per_video, args.max_videos)
    elif args.cmd == "dfdc":
        process_dfdc(args.video_dir, detector, args.frames_per_video, args.max_videos)
    elif args.cmd == "images":
        if not (args.real_dir or args.fake_dir):
            sys.exit("Give --real-dir and/or --fake-dir")
        if args.real_dir:
            process_images(args.real_dir, "real", detector, args.max_images)
        if args.fake_dir:
            process_images(args.fake_dir, "fake", detector, args.max_images)
    print("\nNext step: python -m training.preprocess split   (then: python main.py train)")


if __name__ == "__main__":
    main()
