"""
train.py - fine-tune EfficientNet-B0 to separate REAL from FAKE faces.

Steps each epoch:
  1. TRAIN pass : forward -> loss -> backward -> optimiser step
  2. VALIDATION pass (no weight updates) : measures how well we generalise
  3. Keep the weights with the lowest validation loss (the "best" checkpoint)
The TEST split is never touched here - it is used only by evaluate.py.
"""
import random
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn

import config
from models.deepfake_model import DeepfakeDetector
from models.model_loader import get_device
from training.dataset import get_dataloader
from utils.metrics import compute_metrics
from utils.report_generator import save_json
from utils.visualization import plot_training_curves


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def run_epoch(model, loader, criterion, device, optimizer=None):
    """One pass over `loader`. If `optimizer` is given we train, otherwise we only evaluate."""
    training = optimizer is not None
    model.train(training)
    total_loss, correct, count = 0.0, 0, 0
    all_true, all_prob = [], []

    with torch.set_grad_enabled(training):
        for step, (x, y) in enumerate(loader, 1):
            x, y = x.to(device), y.to(device)
            logits = model(x)
            loss = criterion(logits, y)
            if training:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            probs = torch.sigmoid(logits)
            total_loss += loss.item() * y.size(0)
            correct += ((probs >= config.DECISION_THRESHOLD).float() == y).sum().item()
            count += y.size(0)
            all_true.extend(y.detach().cpu().tolist())
            all_prob.extend(probs.detach().cpu().tolist())
            if training and step % 20 == 0:
                print(f"    batch {step}/{len(loader)}  loss {loss.item():.4f}")
    return total_loss / count, correct / count, all_true, all_prob


def train(epochs=None, batch_size=None, lr=None, pretrained=True,
          weights_path=None, num_workers=None):
    epochs = epochs or config.EPOCHS
    lr = lr or config.LEARNING_RATE
    weights_path = weights_path or config.BEST_WEIGHTS
    config.ensure_dirs()
    set_seed(config.SEED)
    device = get_device()
    print(f"Device: {device}")

    train_loader = get_dataloader("train", batch_size, num_workers)
    val_loader = get_dataloader("val", batch_size, num_workers)
    labels = np.array(train_loader.dataset.labels)
    n_fake, n_real = int((labels == 1).sum()), int((labels == 0).sum())
    print(f"Train images: {len(labels)} (REAL {n_real}, FAKE {n_fake}) | "
          f"Val images: {len(val_loader.dataset)}")
    if n_fake == 0 or n_real == 0:
        raise RuntimeError("The training split needs both REAL and FAKE images.")

    try:
        model = DeepfakeDetector(pretrained=pretrained)
    except Exception as err:
        raise RuntimeError(
            "Could not load the ImageNet-pretrained EfficientNet-B0 weights (they are "
            "downloaded automatically the first time; internet is needed once).\n"
            f"Original error: {err}\n"
            "You can train from random weights with --no-pretrained, but accuracy will "
            "usually be much worse.") from err
    model.to(device)

    # Class imbalance: if FAKE images outnumber REAL ones, give each FAKE sample less weight.
    pos_weight = torch.tensor([n_real / n_fake], device=device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)   # sigmoid + binary cross-entropy
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=config.WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=0.5, patience=1)

    history = {k: [] for k in ("train_loss", "val_loss", "train_acc", "val_acc",
                               "val_auc", "val_f1", "lr")}
    best_val, best_epoch, bad_epochs = float("inf"), 0, 0

    for epoch in range(1, epochs + 1):
        # First epoch(s): train only the new head, so random head weights do not damage the backbone.
        frozen = pretrained and epoch <= config.FREEZE_BACKBONE_EPOCHS
        model.set_backbone_trainable(not frozen)
        print(f"\nEpoch {epoch}/{epochs}  (backbone {'frozen' if frozen else 'trainable'})")

        tr_loss, tr_acc, _, _ = run_epoch(model, train_loader, criterion, device, optimizer)
        va_loss, va_acc, yt, yp = run_epoch(model, val_loader, criterion, device)
        vm = compute_metrics(yt, yp)
        scheduler.step(va_loss)

        for k, v in zip(history, (tr_loss, va_loss, tr_acc, va_acc, vm["roc_auc"], vm["f1_score"],
                                  optimizer.param_groups[0]["lr"])):
            history[k].append(v)
        print(f"  train loss {tr_loss:.4f} acc {tr_acc:.4f} | val loss {va_loss:.4f} "
              f"acc {va_acc:.4f} f1 {vm['f1_score']:.4f} auc {vm['roc_auc']}")

        if va_loss < best_val:
            best_val, best_epoch, bad_epochs = va_loss, epoch, 0
            torch.save({
                "model_state": model.state_dict(),
                "epoch": epoch,
                "val_metrics": {k: vm[k] for k in ("accuracy", "precision", "recall", "f1_score", "roc_auc")},
                "val_loss": va_loss,
                "config": {"image_size": config.IMAGE_SIZE, "arch": "efficientnet_b0",
                          "dropout": config.DROPOUT},
                "class_names": config.CLASS_NAMES,
                "trained_at": datetime.now().isoformat(timespec="seconds"),
            }, weights_path)
            print(f"  -> new best model saved to {weights_path}")
        else:
            bad_epochs += 1
            if bad_epochs >= config.EARLY_STOPPING_PATIENCE:
                print(f"  Early stopping: no improvement for {bad_epochs} epochs.")
                break

    save_json(history, config.REPORTS_DIR / "training_history.json")
    plot_training_curves(history, config.REPORTS_DIR / "training_curves.png")
    print(f"\nTraining finished. Best epoch: {best_epoch} (val loss {best_val:.4f}).")
    print(f"Curves: {config.REPORTS_DIR / 'training_curves.png'}")
    print("Next: python main.py evaluate   (measures performance on the untouched test split)")
    return history
