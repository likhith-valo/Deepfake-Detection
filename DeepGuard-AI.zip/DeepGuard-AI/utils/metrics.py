"""
metrics.py - classification metrics computed from REAL predictions only.

FAKE is the positive class (label 1):
  precision = of everything we called FAKE, how much really was FAKE
  recall    = of all real FAKES, how many we caught
  f1        = harmonic mean of precision and recall
"""
import numpy as np
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             f1_score, precision_score, recall_score, roc_auc_score)

import config


def compute_metrics(y_true, y_prob, threshold=None):
    threshold = config.DECISION_THRESHOLD if threshold is None else threshold
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob, dtype=float)
    y_pred = (y_prob >= threshold).astype(int)

    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = (int(v) for v in cm.ravel())
    both_classes = len(set(y_true.tolist())) == 2

    return {
        "num_samples": int(len(y_true)),
        "threshold": float(threshold),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1_score": float(f1_score(y_true, y_pred, zero_division=0)),
        "specificity": float(tn / (tn + fp)) if (tn + fp) else 0.0,
        "roc_auc": float(roc_auc_score(y_true, y_prob)) if both_classes else None,
        "confusion_matrix": cm.tolist(),          # [[TN, FP], [FN, TP]]
        "tn": tn, "fp": fp, "fn": fn, "tp": tp,
        "classification_report": classification_report(
            y_true, y_pred, labels=[0, 1], target_names=config.CLASS_NAMES, zero_division=0),
    }
