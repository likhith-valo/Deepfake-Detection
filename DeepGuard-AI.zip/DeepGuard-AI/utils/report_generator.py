"""
report_generator.py - write evaluation and detection reports to disk.

Every number in a report is read from real computed results; nothing is hard-coded.
"""
import json
from datetime import datetime
from pathlib import Path

import config


def save_json(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, default=str))
    return str(path)


# --------------------------------------------------------------------------
# Evaluation report (model quality on the test set)
# --------------------------------------------------------------------------
def generate_evaluation_report(metrics, split, history=None, checkpoint=None,
                               figure_files=None, out_path=None):
    out_path = Path(out_path or config.REPORTS_DIR / "evaluation_report.md")
    cm = metrics["confusion_matrix"]
    auc = metrics["roc_auc"]
    lines = [
        "# DeepGuard AI - Model Evaluation Report",
        "",
        f"Generated: {datetime.now():%Y-%m-%d %H:%M}",
        f"Evaluated split: **{split}** ({metrics['num_samples']} face images, face-level evaluation)",
        f"Decision threshold: {metrics['threshold']}",
        "",
        "## Metrics",
        "| Metric | Value |", "|---|---|",
        f"| Accuracy | {metrics['accuracy']:.4f} |",
        f"| Precision (FAKE) | {metrics['precision']:.4f} |",
        f"| Recall (FAKE) | {metrics['recall']:.4f} |",
        f"| F1-score (FAKE) | {metrics['f1_score']:.4f} |",
        f"| Specificity (REAL recall) | {metrics['specificity']:.4f} |",
        f"| ROC-AUC | {'n/a (only one class in data)' if auc is None else f'{auc:.4f}'} |",
        "",
        "## Confusion matrix",
        "| | Predicted REAL | Predicted FAKE |", "|---|---|---|",
        f"| **Actual REAL** | {cm[0][0]} (TN) | {cm[0][1]} (FP) |",
        f"| **Actual FAKE** | {cm[1][0]} (FN) | {cm[1][1]} (TP) |",
        "",
        "## Per-class report",
        "```", metrics["classification_report"], "```",
    ]
    if history and history.get("train_loss"):
        best = min(range(len(history["val_loss"])), key=lambda i: history["val_loss"][i])
        lines += ["", "## Training summary",
                  f"- Epochs run: {len(history['train_loss'])}",
                  f"- Best epoch (lowest validation loss): {best + 1}",
                  f"- Validation loss / accuracy at best epoch: "
                  f"{history['val_loss'][best]:.4f} / {history['val_acc'][best]:.4f}"]
    if checkpoint:
        lines += ["", f"Weights trained at: {checkpoint.get('trained_at', 'unknown')}"]
    if figure_files:
        lines += ["", "## Figures"] + [f"- `{Path(f).name}`" for f in figure_files]
    lines += ["", "## Notes",
              "- Results describe performance on the held-out split of THIS dataset only.",
              "- Frames of the same video / identity never appear in two splits (no leakage).",
              "- Performance on other datasets or newer deepfake methods can be much lower."]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines))
    return str(out_path)


# --------------------------------------------------------------------------
# Detection report (one image / one video)
# --------------------------------------------------------------------------
def _fmt_pct(v):
    return "n/a" if v is None else f"{v:.2%}"


def format_detection_report(result):
    lines = [
        "DeepGuard AI - Detection Report",
        "=" * 40,
        f"File           : {result['path']}",
        f"Media type     : {result['media_type']}",
        f"Face detector  : {result['face_detector']}",
        f"Threshold      : {result['threshold']}",
        f"VERDICT        : {result['overall_label']}",
        f"P(fake)        : {_fmt_pct(result['overall_fake_probability'])}",
        f"Confidence     : {_fmt_pct(result['overall_confidence'])}",
        "", "Summary:", result["summary"], "",
    ]
    if result["media_type"] == "image":
        for f in result["faces"]:
            lines.append(f"  Face {f['face_index']}: {f['label']}  P(fake)={f['fake_probability']:.2%}  box={f['box']}")
    else:
        lines.append(f"Frames analysed: {result['frames_analysed']} (with faces: {result['frames_with_faces']})")
        lines.append("Suspicious timestamps:")
        for s in result["suspicious_frames"]:
            lines.append(f"  {s['timestamp']}  (frame {s['frame_index']})  P(fake)={s['fake_probability']:.2%}")
        if not result["suspicious_frames"]:
            lines.append("  none")
    lines += ["", "Note: the model gives a probability, not proof. Treat borderline scores with caution."]
    return "\n".join(lines)


def save_detection_report(result, out_dir=None):
    out_dir = Path(out_dir or config.REPORTS_DIR)
    stem = f"{Path(result['path']).stem}_{datetime.now():%Y%m%d_%H%M%S}"
    json_path = save_json(result, out_dir / f"{stem}.json")
    txt_path = out_dir / f"{stem}.txt"
    txt_path.write_text(format_detection_report(result))
    return json_path, str(txt_path)
