"""
visualization.py - graphs saved as PNG files (no window pops up, works on servers).
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")          # draw to files only
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.metrics import roc_curve

import config


def _finish(fig, out_path):
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return str(out_path)


def plot_training_curves(history, out_path):
    """Two panels: loss (train vs val) and accuracy (train vs val) per epoch."""
    epochs = range(1, len(history["train_loss"]) + 1)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(epochs, history["train_loss"], marker="o", label="Train loss")
    axes[0].plot(epochs, history["val_loss"], marker="o", label="Validation loss")
    axes[0].set(title="Loss", xlabel="Epoch", ylabel="BCE loss")
    axes[1].plot(epochs, history["train_acc"], marker="o", label="Train accuracy")
    axes[1].plot(epochs, history["val_acc"], marker="o", label="Validation accuracy")
    axes[1].set(title="Accuracy", xlabel="Epoch", ylabel="Accuracy", ylim=(0, 1.02))
    for ax in axes:
        ax.grid(alpha=0.3)
        ax.legend()
    return _finish(fig, out_path)


def plot_confusion_matrix(cm, out_path, title="Confusion matrix"):
    fig, ax = plt.subplots(figsize=(4.5, 4))
    sns.heatmap(np.asarray(cm), annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                xticklabels=config.CLASS_NAMES, yticklabels=config.CLASS_NAMES)
    ax.set(title=title, xlabel="Predicted", ylabel="Actual")
    return _finish(fig, out_path)


def plot_roc_curve(y_true, y_prob, auc, out_path):
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    fig, ax = plt.subplots(figsize=(4.8, 4.2))
    ax.plot(fpr, tpr, label=f"ROC (AUC = {auc:.3f})")
    ax.plot([0, 1], [0, 1], "--", color="grey", label="Random guess")
    ax.set(title="ROC curve", xlabel="False positive rate", ylabel="True positive rate")
    ax.legend(loc="lower right")
    ax.grid(alpha=0.3)
    return _finish(fig, out_path)
